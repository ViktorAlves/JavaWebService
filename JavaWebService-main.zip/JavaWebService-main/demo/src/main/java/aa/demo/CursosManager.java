package  aa.demo;
/* Ana Clara Gierse Raymundo
 * RA: 10428453
 */
import java.util.ArrayList;
import java.util.List;

public class CursosManager{
    private List<Curso> cursos;

    public CursosManager(){
        this.cursos = new ArrayList<>();
        this.cursos.add(new Curso("Ciencia da computação", 3000));
        this.cursos.add(new Curso("Sistema de informação", 3000));
    }

    public List<Curso> getCursos(){
        return this.cursos;
    }
}