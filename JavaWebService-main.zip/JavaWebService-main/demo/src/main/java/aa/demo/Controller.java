package  aa.demo;
/* Ana Clara Gierse Raymundo
 * RA: 10428453
 */
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/cursos")



public class Controller{

}