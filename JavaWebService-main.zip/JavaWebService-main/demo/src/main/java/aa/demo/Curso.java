package  aa.demo;
/* Ana Clara Gierse Raymundo
 * RA: 10428453
 */
public class Curso{
    private String nome;
    public int duracao;

    public Curso(){};

    public Curso(String nome, int duracao){
        this.nome=nome;
        this.duracao=duracao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}